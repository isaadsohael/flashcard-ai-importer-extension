// flashcard-extension/popup.js

document.addEventListener('DOMContentLoaded', async () => {
    // Get references to DOM elements
    const sectionSelect = document.getElementById('section-select');
    const flashcardSelect = document.getElementById('flashcard-select');
    const newSectionInput = document.getElementById('new-section-input');
    const newFlashcardInput = document.getElementById('new-flashcard-input');
    const importBtn = document.getElementById('import-btn');
    const messageBox = document.getElementById('message-box');

    let allSections = []; // Cache the sections fetched from the app

    /**
     * Displays a temporary message in the popup.
     * @param {string} message - The message to display.
     * @param {string} type - 'success' or 'error' for styling.
     */
    function showMessage(message, type = 'success') {
        messageBox.textContent = message;
        // Remove previous type classes and add the new one
        messageBox.classList.remove('hidden', 'success', 'error');
        messageBox.classList.add(type);
        messageBox.classList.remove('hidden'); // Ensure it's visible
        setTimeout(() => {
            messageBox.classList.add('hidden'); // Hide after 3 seconds
        }, 5000);
    }

    /**
     * Populates the section dropdown with data fetched from the flashcard app.
     * @param {Array<Object>} sections - Array of section objects.
     */
    function updateSectionDropdown(sections) {
        sectionSelect.innerHTML = '<option value="">-- Select Section --</option>'; // Default option
        if (sections.length === 0) {
            sectionSelect.innerHTML += '<option value="" disabled>No sections found. Is app open?</option>';
        }
        sections.forEach(section => {
            const option = document.createElement('option');
            option.value = section.id;
            option.textContent = section.title;
            sectionSelect.appendChild(option);
        });
        // Reset flashcard dropdown when sections are updated
        flashcardSelect.innerHTML = '<option value="">Select a section first</option>';
        flashcardSelect.disabled = true;
    }

    /**
     * Populates the flashcard dropdown based on the selected section.
     * @param {string} sectionId - The ID of the selected section.
     */
    function updateFlashcardDropdown(sectionId) {
        flashcardSelect.innerHTML = '<option value="">-- Select Flashcard --</option>'; // Default option
        const selectedSection = allSections.find(s => s.id === Number(sectionId));
        if (selectedSection && selectedSection.flashcards && selectedSection.flashcards.length > 0) {
            selectedSection.flashcards.forEach(flashcard => {
                const option = document.createElement('option');
                option.value = flashcard.id;
                option.textContent = flashcard.title;
                flashcardSelect.appendChild(option);
            });
            flashcardSelect.disabled = false; // Enable flashcard dropdown
        } else {
            flashcardSelect.disabled = true;
            flashcardSelect.innerHTML = '<option value="">No flashcards found in this section</option>';
        }
    }

    /**
     * Requests data from the Flashcard application tab.
     * It executes a function directly in the Flashcard app's main world context
     * to call `window.getFlashcardAppData`.
     */
    async function getAppData() {
        console.log('Popup: Attempting to get app data from Flashcard app tab...');
        // Query for the active tab in the current window (presumed to be the Flashcard app)
        const [flashcardAppTab] = await chrome.tabs.query({ active: true, currentWindow: true });

        if (!flashcardAppTab || !flashcardAppTab.url || !flashcardAppTab.url.startsWith('http')) {
            showMessage('Please open your Flashcard app in a tab (e.g., http://localhost:5173).', 'error');
            console.error('Popup: No active HTTP(S) tab found for Flashcard app.');
            return;
        }

        try {
            // Execute a function directly in the page's main world context of the Flashcard app tab
            // Added a small delay to ensure the app is fully loaded and interface is ready
            await new Promise(resolve => setTimeout(resolve, 500)); // Wait 500ms

            const response = await chrome.scripting.executeScript({
                target: { tabId: flashcardAppTab.id },
                function: () => {
                    // This function runs in the main world of the web page
                    console.log('Flashcard App Page Context: Checking for window.getFlashcardAppData...');
                    if (window.getFlashcardAppData) {
                        console.log('Flashcard App Page Context: Calling window.getFlashcardAppData');
                        return window.getFlashcardAppData();
                    } else {
                        console.warn('Flashcard App Page Context: window.getFlashcardAppData not found. App not ready or interface not set up.');
                        return '[]'; // Return empty array string if function not found
                    }
                },
                world: 'MAIN' // Crucial: Execute in the page's main JavaScript context
            });

            console.log('Popup: Response from executeScript (getAppData):', response);

            // Check if the script execution was successful and returned data
            if (response && response[0] && response[0].result !== undefined) {
                try {
                    allSections = JSON.parse(response[0].result);
                    console.log('Popup: Successfully parsed app data:', allSections);
                    updateSectionDropdown(allSections);
                } catch (e) {
                    console.error('Popup: Failed to parse app data received from Flashcard app:', e);
                    showMessage('Received invalid data from app. See console for details.', 'error');
                    allSections = [];
                    updateSectionDropdown([]);
                }
            } else {
                showMessage('Could not load sections from app. Is your Flashcard app open and running?', 'error');
                console.error('Popup: No valid result from script execution for getAppData from Flashcard app:', response);
                allSections = [];
                updateSectionDropdown([]);
            }
        } catch (error) {
            showMessage('Error communicating with your Flashcard app. Ensure it is running.', 'error');
            console.error('Popup: Script execution error for getAppData:', error);
            allSections = [];
            updateSectionDropdown([]);
        }
    }

    // Event listener for section selection change
    sectionSelect.addEventListener('change', () => {
        updateFlashcardDropdown(sectionSelect.value);
        // Clear new section/flashcard inputs if a selection is made
        if (sectionSelect.value) {
            newSectionInput.value = '';
        }
    });

    // Event listener for flashcard selection change
    flashcardSelect.addEventListener('change', () => {
        // Clear new flashcard input if a flashcard is selected
        if (flashcardSelect.value) {
            newFlashcardInput.value = '';
        }
    });

    // Handle "Import from ChatGPT" button click
    importBtn.addEventListener('click', async () => {
        const selectedSectionId = sectionSelect.value;
        const selectedFlashcardId = flashcardSelect.value;
        const newSectionTitle = newSectionInput.value.trim();
        const newFlashcardName = newFlashcardInput.value.trim();

        let targetSectionId = selectedSectionId ? Number(selectedSectionId) : null;
        let targetFlashcardId = selectedFlashcardId ? Number(selectedFlashcardId) : null;

        // Validation for new section/flashcard creation
        if (newSectionTitle && selectedSectionId) {
            showMessage("Please either select an existing section OR enter a new section title, not both.", "error");
            return;
        }
        if (newFlashcardName && selectedFlashcardId) {
            showMessage("Please either select an existing flashcard OR enter a new flashcard name, not both.", "error");
            return;
        }

        // Logic to create a new section if title is provided
        if (newSectionTitle && !targetSectionId) {
            targetSectionId = Date.now(); // Generate a temporary ID for the new section
            const newSection = { id: targetSectionId, title: newSectionTitle, flashcards: [] };
            allSections.push(newSection); // Add to local state for immediate dropdown update (simulated)
            showMessage(`New section "${newSectionTitle}" will be created and added to app.`);
        }

        // Logic to create a new flashcard if name is provided
        if (newFlashcardName && targetSectionId && !targetFlashcardId) {
            targetFlashcardId = Date.now(); // Generate a temporary ID for the new flashcard
            const targetSection = allSections.find(s => s.id === targetSectionId);
            if (targetSection) {
                if (!targetSection.flashcards) targetSection.flashcards = [];
                targetSection.flashcards.push({ id: targetFlashcardId, title: newFlashcardName, cards: [] });
                showMessage(`New flashcard "${newFlashcardName}" will be created and added to app.`);
            } else {
                showMessage("Cannot add new flashcard without a valid section. Select or create one.", "error");
                return;
            }
        }

        if (!targetSectionId || !targetFlashcardId) {
            showMessage("Please select an existing or create a new section AND flashcard.", "error");
            return;
        }

        // Find the ChatGPT tab (any open tab with chat.openai.com or chatgpt.com)
        const chatGptTabs = await chrome.tabs.query({ url: ["*://chat.openai.com/*", "*://chatgpt.com/*"] });
        if (chatGptTabs.length === 0) {
            showMessage('Please open chat.openai.com or chatgpt.com in a browser tab to import flashcards.', 'error');
            return;
        }
        const chatGptTab = chatGptTabs[0]; // Take the first one found

        // Get the Flashcard app tab (the active one in the current window, where the popup was opened)
        const [flashcardAppTab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!flashcardAppTab || !flashcardAppTab.url || !flashcardAppTab.url.startsWith('http')) {
            showMessage('Flashcard app tab is not active or not an HTTP(S) page. Please ensure it is open.', 'error');
            return;
        }


        showMessage('Extracting flashcards from ChatGPT...');
        try {
            // Define the parsing logic directly within the executeScript function.
            // This function will be stringified and executed in the ChatGPT tab's isolated world.
            const parseChatGPTResponseInContext = () => {
                const flashcards = [];

                // Updated selector for ChatGPT assistant messages
                const bubbles = document.querySelectorAll('[data-message-author-role="assistant"]');
                
                for (let i = bubbles.length - 1; i >= 0; i--) {
                    const el = bubbles[i];

                    // The rest of your logic remains the same...
                    const content = el.innerText || el.textContent || '';

                    console.log("🧠 Extracting from message:\n", content);

                    // Try to extract blocks that look like: Flashcard N \n Q: ... \n A: ...
                    const lines = content.split(/\n+/);
                    let current = {};
                    for (let line of lines) {
                        line = line.trim();
                        if (/^Flashcard\s*\d+/i.test(line)) {
                            if (current.question && current.answer) flashcards.push({ ...current });
                            current = {}; // Start new card
                        } else if (/^Q\s*[:：]?\s*/i.test(line)) {
                            current.question = line.replace(/^Q\s*[:：]?\s*/i, '').trim();
                        } else if (/^A\s*[:：]?\s*/i.test(line)) {
                            current.answer = line.replace(/^A\s*[:：]?\s*/i, '').trim();
                        }
                    }
                    if (current.question && current.answer) flashcards.push({ ...current });

                    if (flashcards.length > 0) break;
                }
                return flashcards;
            };

            // Execute the parsing function directly in the ChatGPT tab's isolated world
            const parsedCardsResult = await chrome.scripting.executeScript({
                target: { tabId: chatGptTab.id },
                function: parseChatGPTResponseInContext // Pass the function itself
            });

            console.log('Popup: Received parsedCards from content script:', parsedCardsResult);
            const parsedCards = parsedCardsResult && parsedCardsResult[0] ? parsedCardsResult[0].result : [];
            

            if (parsedCards && parsedCards.length > 0) {
                showMessage(`Found ${parsedCards.length} flashcards. Adding to app...`);

                // Fetch current cards from the target flashcard (in the app tab)
                const getExistingCardsResult = await chrome.scripting.executeScript({
                    target: { tabId: flashcardAppTab.id },
                    function: (sectionId, flashcardId) => {
                        if (window.getFlashcardAppData) {
                            const sections = JSON.parse(window.getFlashcardAppData());
                            const section = sections.find(s => s.id === Number(sectionId));
                            if (!section) return [];
                            const flashcard = section.flashcards.find(f => f.id === Number(flashcardId));
                            return flashcard && flashcard.cards ? flashcard.cards : [];
                        }
                        return [];
                    },
                    args: [targetSectionId, targetFlashcardId],
                    world: 'MAIN'
                });
                const existingCards = getExistingCardsResult && getExistingCardsResult[0] ? getExistingCardsResult[0].result : [];

                // Filter out duplicates (by question, case-insensitive)
                const existingQuestions = new Set(existingCards.map(card => card.question.trim().toLowerCase()));
                const uniqueParsedCards = parsedCards.filter(card => 
                    !existingQuestions.has(card.question.trim().toLowerCase())
                );

                // Assign unique IDs to each card
                const parsedCardsWithIds = uniqueParsedCards.map(card => ({
                    ...card,
                    id: Date.now().toString() + Math.random().toString(36).substr(2, 9)
                }));

                // Send parsed cards to the flashcard app by executing a function directly in the page's main world
                console.log('Popup: Calling addFlashcardsToApp in Flashcard app page context via executeScript.');
                const successResult = await chrome.scripting.executeScript({
                    target: { tabId: flashcardAppTab.id },
                    function: (sectionId, flashcardId, cardsJson) => {
                        // This function runs in the main world of the web page
                        if (window.addFlashcardsToApp) {
                            console.log('Page Context: Calling window.addFlashcardsToApp');
                            return window.addFlashcardsToApp(sectionId, flashcardId, cardsJson);
                        } else {
                            console.error('Page Context: window.addFlashcardsToApp not found.');
                            return false; // Indicate failure
                        }
                    },
                    args: [targetSectionId, targetFlashcardId, JSON.stringify(parsedCardsWithIds)],
                    world: 'MAIN' // Crucial: Execute in the page's main JavaScript context
                });

                console.log('Popup: Result from adding flashcards to app:', successResult);

                if (successResult && successResult[0] && successResult[0].result) {
                    showMessage(`Successfully added ${parsedCards.length} flashcards!`, 'success');
                    // Clear inputs and refresh dropdowns after successful import
                    newSectionInput.value = '';
                    newFlashcardInput.value = '';
                    await getAppData(); // Re-fetch data to update dropdowns with new section/flashcard
                } else {
                    showMessage('Failed to add flashcards to the app. See console for errors.', 'error');
                }
            } else {
                showMessage('No flashcards found in ChatGPT response. Ensure format "Flashcard N: Q: A:"', 'error');
            }
        } catch (error) {
            showMessage('Error during import process. Ensure both ChatGPT and Flashcard app tabs are open.', 'error');
            console.error('Popup: Import process error:', error);
        }
    });

    // Initial load of sections when popup opens
    getAppData();
});
