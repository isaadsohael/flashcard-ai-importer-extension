// flashcard-extension/popup.js

document.addEventListener('DOMContentLoaded', async () => {
    // Get references to DOM elements
    const sectionSelect = document.getElementById('section-select');
    const flashcardSelect = document.getElementById('flashcard-select');
    const newSectionInput = document.getElementById('new-section-input');
    const newFlashcardInput = document.getElementById('new-flashcard-input');
    const importBtn = document.getElementById('import-btn');
    const messageBox = document.getElementById('message-box');
    const previewContainer = document.getElementById('preview-container');
    const previewForm = document.getElementById('preview-form');
    const confirmImportBtn = document.getElementById('confirm-import-btn');
    const selectAllContainer = document.getElementById('select-all-container');

    let allSections = []; // Cache the sections fetched from the app
    let flashcardAppTab = null;
    let currentTargetSectionId = null; // Renamed to avoid confusion with original targetSectionId in scope
    let currentTargetFlashcardId = null; // Renamed

    /**
     * Displays a temporary message in the popup.
     * @param {string} message - The message to display.
     * @param {string} type - 'success' or 'error' for styling.
     */
    function showMessage(message, type = 'success') {
        messageBox.textContent = message;
        messageBox.classList.remove('hidden', 'success', 'error');
        messageBox.classList.add(type);
        messageBox.classList.remove('hidden');
        setTimeout(() => {
            messageBox.classList.add('hidden');
        }, 5000);
    }

    /**
     * Populates the section dropdown with data fetched from the flashcard app.
     * @param {Array<Object>} sections - Array of section objects.
     */
    function updateSectionDropdown(sections) {
        sectionSelect.innerHTML = '<option value="">-- Select Section --</option>';
        if (sections.length === 0) {
            sectionSelect.innerHTML += '<option value="" disabled>No sections found. Is app open?</option>';
        }
        sections.forEach(section => {
            const option = document.createElement('option');
            // Ensure section.id is used as value
            option.value = section.id;
            option.textContent = section.title;
            sectionSelect.appendChild(option);
        });
        // Reset flashcard dropdown when sections are updated
        flashcardSelect.innerHTML = '<option value="">Select a section first</option>';
        flashcardSelect.disabled = true;

        // Try to re-select previously selected values if they still exist
        if (currentTargetSectionId) {
            if (sections.some(s => s.id === currentTargetSectionId)) {
                sectionSelect.value = currentTargetSectionId;
                updateFlashcardDropdown(currentTargetSectionId);
                if (currentTargetFlashcardId) {
                    const selectedSection = sections.find(s => s.id === currentTargetSectionId);
                    if (selectedSection && selectedSection.flashcards.some(f => f.id === currentTargetFlashcardId)) {
                        flashcardSelect.value = currentTargetFlashcardId;
                    } else {
                        currentTargetFlashcardId = null; // Reset if flashcard no longer exists
                    }
                }
            } else {
                currentTargetSectionId = null; // Reset if section no longer exists
            }
        }
    }

    /**
     * Populates the flashcard dropdown based on the selected section.
     * @param {string} sectionId - The ID of the selected section.
     */
    function updateFlashcardDropdown(sectionId) {
        flashcardSelect.innerHTML = '<option value="">-- Select Flashcard --</option>';
        // Find section by its ID (which is now a string from Firestore)
        const selectedSection = allSections.find(s => s.id === sectionId);
        if (selectedSection && selectedSection.flashcards && selectedSection.flashcards.length > 0) {
            selectedSection.flashcards.forEach(flashcard => {
                const option = document.createElement('option');
                // Ensure flashcard.id is used as value
                option.value = flashcard.id;
                option.textContent = flashcard.title;
                flashcardSelect.appendChild(option);
            });
            flashcardSelect.disabled = false;
        } else {
            flashcardSelect.disabled = true;
            flashcardSelect.innerHTML = '<option value="">No flashcards found in this section</option>';
        }
    }

    /**
     * Requests data from the Flashcard application tab.
     * It executes a function directly in the Flashcard app's main world context
     * to call `window.getFlashcardAppData`.
     */
    async function getAppData() {
        console.log('Popup: Attempting to get app data from Flashcard app tab...');
        const [flashcardAppTabQuery] = await chrome.tabs.query({ active: true, currentWindow: true });

        if (!flashcardAppTabQuery || !flashcardAppTabQuery.url || !flashcardAppTabQuery.url.startsWith('http')) {
            showMessage('Please open your Flashcard app in a tab.', 'error');
            console.error('Popup: No active HTTP(S) tab found for Flashcard app.');
            return;
        }
        flashcardAppTab = flashcardAppTabQuery; // Assign to global variable for later use

        try {
            await new Promise(resolve => setTimeout(resolve, 1000)); // Increased delay for app to fully load

            const response = await chrome.scripting.executeScript({
                target: { tabId: flashcardAppTab.id },
                function: () => {
                    if (window.getFlashcardAppData) {
                        return window.getFlashcardAppData();
                    } else {
                        console.warn('Flashcard App Page Context: window.getFlashcardAppData not found. App not ready or interface not set up.');
                        return '[]';
                    }
                },
                world: 'MAIN'
            });

            console.log('Popup: Response from executeScript (getAppData):', response);

            if (response && response[0] && response[0].result !== undefined) {
                try {
                    allSections = JSON.parse(response[0].result);
                    console.log('Popup: Successfully parsed app data:', allSections);
                    updateSectionDropdown(allSections);
                } catch (e) {
                    console.error('Popup: Failed to parse app data received from Flashcard app:', e);
                    showMessage('Received invalid data from app. See console for details.', 'error');
                    allSections = [];
                    updateSectionDropdown([]);
                }
            } else {
                showMessage('Could not load sections from app. Is your Flashcard app open and running?', 'error');
                console.error('Popup: No valid result from script execution for getAppData from Flashcard app:', response);
                allSections = [];
                updateSectionDropdown([]);
            }
        } catch (error) {
            showMessage('Error communicating with your Flashcard app. Ensure it is running.', 'error');
            console.error('Popup: Script execution error for getAppData:', error);
            allSections = [];
            updateSectionDropdown([]);
        }
    }

    // Event listener for section selection change
    sectionSelect.addEventListener('change', () => {
        currentTargetSectionId = sectionSelect.value;
        currentTargetFlashcardId = null; // Reset flashcard selection
        flashcardSelect.value = ""; // Clear flashcard dropdown visual
        updateFlashcardDropdown(currentTargetSectionId);
        if (sectionSelect.value) {
            newSectionInput.value = ''; // Clear new section input if existing selected
        }
    });

    // Event listener for flashcard selection change
    flashcardSelect.addEventListener('change', () => {
        currentTargetFlashcardId = flashcardSelect.value;
        if (flashcardSelect.value) {
            newFlashcardInput.value = ''; // Clear new flashcard input if existing selected
        }
    });

    // Clear related inputs when typing in new section/flashcard fields
    newSectionInput.addEventListener('input', () => {
        if (newSectionInput.value.trim()) {
            sectionSelect.value = ''; // Clear section selection
            flashcardSelect.innerHTML = '<option value="">Select a section first</option>';
            flashcardSelect.disabled = true;
            newFlashcardInput.value = ''; // Also clear new flashcard input
            currentTargetSectionId = null;
            currentTargetFlashcardId = null;
        }
    });

    newFlashcardInput.addEventListener('input', () => {
        if (newFlashcardInput.value.trim()) {
            flashcardSelect.value = ''; // Clear flashcard selection
            currentTargetFlashcardId = null;
        }
    });


    // Handle "Import from ChatGPT" button click
    importBtn.addEventListener('click', async () => {
        const selectedSectionId = sectionSelect.value;
        const selectedFlashcardId = flashcardSelect.value;
        const newSectionTitle = newSectionInput.value.trim();
        const newFlashcardName = newFlashcardInput.value.trim();

        currentTargetSectionId = selectedSectionId;
        currentTargetFlashcardId = selectedFlashcardId;

        // Validation for new section/flashcard creation
        if (newSectionTitle && selectedSectionId) {
            showMessage("Please either select an existing section OR enter a new section title, not both.", "error");
            return;
        }
        if (newFlashcardName && selectedFlashcardId) {
            showMessage("Please either select an existing flashcard OR enter a new flashcard name, not both.", "error");
            return;
        }

        if (!selectedSectionId && !newSectionTitle) {
            showMessage("Please select an existing section or enter a new section title.", "error");
            return;
        }
        if (!selectedFlashcardId && !newFlashcardName) {
            showMessage("Please select an existing flashcard or enter a new flashcard name.", "error");
            return;
        }
        if (selectedSectionId && newFlashcardName && !selectedFlashcardId) {
             // Case: existing section selected, new flashcard name provided
             // This is fine. currentTargetSectionId is already selectedSectionId.
        }


        // Find the ChatGPT tab
        const chatGptTabs = await chrome.tabs.query({ url: ["*://chat.openai.com/*", "*://chatgpt.com/*"] });
        if (chatGptTabs.length === 0) {
            showMessage('Please open chat.openai.com or chatgpt.com in a browser tab to import flashcards.', 'error');
            return;
        }
        const chatGptTab = chatGptTabs[0];

        // Ensure flashcard app tab is still the active one
        const [foundFlashcardAppTab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!foundFlashcardAppTab || !foundFlashcardAppTab.url || !foundFlashcardAppTab.url.startsWith('http')) {
            showMessage('Flashcard app tab is not active or not an HTTP(S) page. Please ensure it is open.', 'error');
            return;
        }
        flashcardAppTab = foundFlashcardAppTab; // Update global reference


        showMessage('Extracting flashcards from ChatGPT...');
        try {
            // Execute the parsing function directly in the ChatGPT tab's isolated world
            const parseChatGPTResponseInContext = () => {
                const flashcards = [];
                const bubbles = document.querySelectorAll('[data-message-author-role="assistant"]');
                const qRegex = /^(\d+\s*[\.\)]\s*)?(<b>)?\s*Q[\.:：]?\s*(<\/b>)?/i;
                const aRegex = /^(\d+\s*[\.\)]\s*)?(<b>)?\s*A[\.:：]?\s*(<\/b>)?/i;
                const flashcardHeaderRegex = /^Flashcard\s*\d+/i;

                for (let i = 0; i < bubbles.length; i++) {
                    const el = bubbles[i];
                    let html = el.innerHTML || '';
                    html = html.replace(/<br\s*\/?>/gi, '\n');
                    html = html.replace(/<b>/gi, '').replace(/<\/b>/gi, '');

                    const lines = html.split(/\n+/);
                    let current = {};
                    let collectingAnswer = false;
                    let answerLines = [];

                    for (let line of lines) {
                        let cleanLine = line.replace(/<\/?[^>]+(>|$)/g, '').trim();

                        if (flashcardHeaderRegex.test(cleanLine)) {
                            if (current.question && answerLines.length) {
                                current.answer = answerLines.join('\n').trim();
                                if (current.question && current.answer) flashcards.push({ ...current });
                            }
                            current = {};
                            answerLines = [];
                            collectingAnswer = false;
                            continue;
                        }

                        if (qRegex.test(cleanLine)) {
                            if (current.question && answerLines.length) {
                                current.answer = answerLines.join('\n').trim();
                                if (current.question && current.answer) flashcards.push({ ...current });
                            }
                            current = {};
                            answerLines = [];
                            collectingAnswer = false;
                            current.question = cleanLine.replace(qRegex, '').trim();
                        } else if (aRegex.test(cleanLine)) {
                            collectingAnswer = true;
                            answerLines = [];
                            let answerStart = cleanLine.replace(aRegex, '').trim();
                            if (answerStart) answerLines.push(answerStart);
                        } else if (collectingAnswer && cleanLine) {
                            if (!flashcardHeaderRegex.test(cleanLine)) {
                                answerLines.push(cleanLine);
                            }
                        }
                    }
                    if (current.question && answerLines.length) {
                        current.answer = answerLines.join('\n').trim();
                        if (current.question && current.answer) flashcards.push({ ...current });
                    }
                }
                return flashcards;
            };

            const parsedCardsResult = await chrome.scripting.executeScript({
                target: { tabId: chatGptTab.id },
                function: parseChatGPTResponseInContext
            });

            console.log('Popup: Received parsedCards from content script:', parsedCardsResult);
            const parsedCards = parsedCardsResult && parsedCardsResult[0] ? parsedCardsResult[0].result : [];

            if (parsedCards && parsedCards.length > 0) {
                // If new section or flashcard titles are provided, create them first
                if (newSectionTitle && !currentTargetSectionId) {
                    showMessage(`Creating new section "${newSectionTitle}"...`);
                    const newId = await chrome.scripting.executeScript({
                        target: { tabId: flashcardAppTab.id },
                        function: (title) => {
                            if (window.createFlashcardSection) {
                                return window.createFlashcardSection(title);
                            }
                            return null;
                        },
                        args: [newSectionTitle],
                        world: 'MAIN'
                    });
                    if (newId && newId[0] && newId[0].result) {
                        currentTargetSectionId = newId[0].result;
                        showMessage(`Section "${newSectionTitle}" created. ID: ${currentTargetSectionId}`);
                        // Re-fetch app data to update dropdowns with the new section
                        await getAppData();
                        sectionSelect.value = currentTargetSectionId; // Select the newly created section
                        updateFlashcardDropdown(currentTargetSectionId); // Update flashcard dropdown
                    } else {
                        showMessage('Failed to create new section. Please try again.', 'error');
                        return;
                    }
                }

                if (newFlashcardName && currentTargetSectionId && !currentTargetFlashcardId) {
                    showMessage(`Creating new flashcard "${newFlashcardName}" in section...`);
                    const newId = await chrome.scripting.executeScript({
                        target: { tabId: flashcardAppTab.id },
                        function: (sectionId, title) => {
                            if (window.createFlashcard) {
                                return window.createFlashcard(sectionId, title);
                            }
                            return null;
                        },
                        args: [currentTargetSectionId, newFlashcardName],
                        world: 'MAIN'
                    });
                    if (newId && newId[0] && newId[0].result) {
                        currentTargetFlashcardId = newId[0].result;
                        showMessage(`Flashcard "${newFlashcardName}" created. ID: ${currentTargetFlashcardId}`);
                        // Re-fetch app data to update dropdowns with the new flashcard
                        await getAppData();
                        flashcardSelect.value = currentTargetFlashcardId; // Select the newly created flashcard
                    } else {
                        showMessage('Failed to create new flashcard. Please try again.', 'error');
                        return;
                    }
                }

                // After potential creation, ensure IDs are set
                if (!currentTargetSectionId || !currentTargetFlashcardId) {
                    showMessage("Internal error: Target section or flashcard ID not set after creation/selection. Please re-select or try again.", "error");
                    return;
                }

                showPreview(parsedCards);
                window._parsedCardsToImport = parsedCards; // Store for later confirmation
                // Hide input fields after successful parsing and showing preview
                newSectionInput.value = '';
                newFlashcardInput.value = '';
                return;
            } else {
                showMessage('No flashcards found in ChatGPT response. Ensure format "Q: ... A: ..."', 'error');
            }
        } catch (error) {
            showMessage('Error during import process. Ensure both ChatGPT and Flashcard app tabs are open.', 'error');
            console.error('Popup: Import process error:', error);
        }
    });

    // Confirm import handler
    confirmImportBtn.addEventListener('click', async (e) => {
        e.preventDefault();
        const parsedCards = window._parsedCardsToImport || [];
        const checked = Array.from(previewForm.querySelectorAll('input[type="checkbox"]'))
            .map((cb, idx) => cb.checked ? idx : -1)
            .filter(idx => idx !== -1);
        const selectedCards = checked.map(idx => parsedCards[idx]);

        if (!selectedCards.length) {
            showMessage('Please select at least one flashcard to import.', 'error');
            return;
        }

        if (!flashcardAppTab || !currentTargetSectionId || !currentTargetFlashcardId) {
            showMessage("Error: Flashcard app connection lost or target not set. Please re-open the app and try again.", "error");
            return;
        }

        showMessage(`Importing ${selectedCards.length} flashcards...`);
        hidePreview();

        // No longer fetching existing cards for client-side deduplication,
        // as `addFlashcardsToApp` in the main app will handle adding them
        // and Firestore handles document IDs. Deduplication by content can be done in main app ViewEdit.jsx.

        // Send parsed cards to the flashcard app by executing a function directly in the page's main world
        const successResult = await chrome.scripting.executeScript({
            target: { tabId: flashcardAppTab.id },
            function: (sectionId, flashcardId, cardsJson) => {
                if (window.addFlashcardsToApp) {
                    return window.addFlashcardsToApp(sectionId, flashcardId, cardsJson);
                } else {
                    return false;
                }
            },
            args: [currentTargetSectionId, currentTargetFlashcardId, JSON.stringify(selectedCards)], // Pass selectedCards directly
            world: 'MAIN'
        });

        if (successResult && successResult[0] && successResult[0].result) {
            showMessage(`Successfully added ${selectedCards.length} flashcards!`, 'success');
            // Refresh data in popup after successful import
            await getAppData();
            // Re-select the section and flashcard that were targeted
            sectionSelect.value = currentTargetSectionId;
            updateFlashcardDropdown(currentTargetSectionId);
            flashcardSelect.value = currentTargetFlashcardId;
        } else {
            showMessage('Failed to add flashcards to the app. See console for errors.', 'error');
        }
    });

    // Helper to render preview checkboxes
    function showPreview(parsedCards) {
        previewForm.innerHTML = '';
        selectAllContainer.innerHTML = '';
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'text-xs px-2 py-1 rounded bg-gray-600 hover:bg-gray-500 text-white border border-gray-400';
        btn.textContent = 'Select All';
        btn.setAttribute('aria-pressed', 'false');
        selectAllContainer.appendChild(btn);

        btn.addEventListener('click', function () {
            const checkboxes = Array.from(previewForm.querySelectorAll('input[type="checkbox"]'));
            const allChecked = checkboxes.every(cb => cb.checked);
            checkboxes.forEach(cb => { cb.checked = !allChecked; });
            btn.textContent = allChecked ? 'Select All' : 'Deselect All';
            btn.setAttribute('aria-pressed', (!allChecked).toString());
        });

        btn.textContent = 'Select All';
        btn.setAttribute('aria-pressed', 'false');

        parsedCards.forEach((card, idx) => {
            const id = `preview-fc-${idx}`;
            const div = document.createElement('div');
            div.className = "bg-gray-700 p-2 rounded";
            div.innerHTML = `
                <label class="flex items-start space-x-2">
                    <input type="checkbox" id="${id}" checked class="mt-1">
                    <span>
                        <span class="font-bold">Q:</span> ${card.question}<br>
                        <span class="font-bold">A:</span> ${card.answer}
                    </span>
                </label>
            `;
            previewForm.appendChild(div);
        });
        previewContainer.classList.remove('hidden');
    }

    // Hide preview
    function hidePreview() {
        previewContainer.classList.add('hidden');
        previewForm.innerHTML = '';
    }

    // Initial load of sections when popup opens
    getAppData();

    let lastCheckedIndex = null;

    previewForm.addEventListener('click', function (e) {
        if (e.target && e.target.type === 'checkbox') {
            const checkboxes = Array.from(previewForm.querySelectorAll('input[type="checkbox"]'));
            const clickedIndex = checkboxes.indexOf(e.target);

            if (e.shiftKey && lastCheckedIndex !== null) {
                const [start, end] = [lastCheckedIndex, clickedIndex].sort((a, b) => a - b);
                const shouldCheck = e.target.checked;
                for (let i = start; i <= end; i++) {
                    checkboxes[i].checked = shouldCheck;
                }
            }
            lastCheckedIndex = clickedIndex;
        }
    });
});
