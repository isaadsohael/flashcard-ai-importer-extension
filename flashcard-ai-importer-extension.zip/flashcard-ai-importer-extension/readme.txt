----HOW TO USE THE EXTENSION----

1. After Unzipping, go to browser extension tab
2. Turn on Developer Option (generally at top-right side of the screen)
3. Click on Load Unpack (generally at top-left side of the screen)
4. You are ready to go (YOU MAY PIN THE EXTENSION TO USE EASILY)


----HOW TO GENERATE AI FLASHCARDS----
1. Open chatgpt website and generate flashcards or open generated flashcard chat
2. KEEP the tab open and go to RizzFlash webapp
3. Click on AI FLASHCARD AI IMPORTER extension
4. Select Desired Flashcard Section and Topic
5. Click on Import From ChatGpt Button
6. Select the Flashcards you want to import