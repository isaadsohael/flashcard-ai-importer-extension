// flashcard-extension/content.js
// This script runs in an isolated world on chat.openai.com or chatgpt.com.
// Its primary purpose is to establish a script context within the tab,
// allowing the extension's popup.js to execute functions (like parsing)
// directly in this isolated world using chrome.scripting.executeScript.
// The actual parsing logic has been moved to popup.js for direct execution.
