// flashcard-extension/background.js
// This is the background service worker for the extension.

// For this specific setup, the background script is minimal.
// Popup.js communicates directly with content.js using chrome.tabs.sendMessage
// and chrome.scripting.executeScript.
// If your extension needed more complex persistent state,
// cross-tab communication, or event handling (e.g., alarms, context menus),
// that logic would reside here.

// No specific event listeners or functions are needed in this file for the
// current requirements of this Flashcard AI Importer extension.
